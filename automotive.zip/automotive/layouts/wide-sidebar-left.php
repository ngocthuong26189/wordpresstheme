<?php get_header(); ?>
	
    <?php listing_template("wide_left"); ?>

<?php get_footer(); ?>